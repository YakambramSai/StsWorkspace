package com.apixandru.casestudy;

/**
 * @author Alexandru-Constantin Bledea
 * @since Sep 03, 2016
 */
public interface OpinionatorClient {

    String askForOpinionAboutName(String name) throws Exception;

}
