package com.apixandru.casestudy;

/**
 * @author Alexandru-Constantin Bledea
 * @since Nov 22, 2016
 */
public interface ExampleService {

    Object executeBadInsert();

    Object executeOkQuery();

}
