package com.apixandru.weblogicjta;

public interface JmsService {

    void send(SampleEntity entity);

}
