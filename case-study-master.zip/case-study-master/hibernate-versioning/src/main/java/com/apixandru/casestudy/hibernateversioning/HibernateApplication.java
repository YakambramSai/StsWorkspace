package com.apixandru.casestudy.hibernateversioning;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Alexandru-Constantin Bledea
 * @since March 02, 2017
 */
@SpringBootApplication
public class HibernateApplication {
}
